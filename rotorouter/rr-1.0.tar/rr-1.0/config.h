#define	BASEPORT	33434		/* assumption based on defaults */
#define	MAX_SOCK	90		/* assuming ttl of 30 * 3 probes */
#undef FINAL_HOP_LOOKS_LIKE_LINUX	/* Define this to make your final */
					/* hop look like linux (ttl=64) */
